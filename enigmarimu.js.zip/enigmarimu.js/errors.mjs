class ValueError extends Error {}

export { ValueError }